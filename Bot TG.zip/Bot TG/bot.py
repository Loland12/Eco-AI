import telebot
from config import TOKEN
from logic_ai import get_class


bot = telebot.TeleBot(TOKEN)

@bot.message_handler(content_types=['photo'])
def send_class(message):

    file_info = bot.get_file(message.photo[-1].file_id)

    file_name = file_info.file_path.split('/')[-1]

    downloaded_file = bot.download_file(file_info.file_path)

    with open(file_name, 'wb') as new_file:

        new_file.write(downloaded_file)
    
    result=get_class(file_name)

    bot.reply_to(message, result)

bot.infinity_polling()